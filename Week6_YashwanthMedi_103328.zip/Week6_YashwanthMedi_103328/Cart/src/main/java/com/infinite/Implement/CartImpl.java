package com.infinite.Implement;

import java.util.List;

import javax.transaction.Transaction;

import org.apache.log4j.BasicConfigurator;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infinite.Daohelper.CartHelper;
import com.infinite.Pojo.Cart;
import com.infinite.interfac.ICart;

public class CartImpl  implements ICart{
	Session sessionObj;
	static SessionFactory sessionFactoryObj;
	org.hibernate.Transaction tx = null;

	public void insert(String pname, int price, int quantity, int ttl) {
		// TODO Auto-generated method stub
		try {
			BasicConfigurator.configure();
			sessionObj = CartHelper.buildSessionFactory().openSession();
			tx = sessionObj.beginTransaction();
			Cart p = new Cart();
			p.setProductName(pname);
			p.setPrice(price);
			p.setQuantity(quantity);
			p.setTotal(ttl);
			sessionObj.save(p);
			tx.commit();
		} catch (HibernateException e) {

 

			e.printStackTrace();
		} finally {
			// Close hibernate session.
			// sessionObj.close();
		}
	}
	

	public void update() {
		// TODO Auto-generated method stub
		
	}

	public void delete() {
		// TODO Auto-generated method stub
		
	}

	public List<Cart> display() {
		// TODO Auto-generated method stub
		List<Cart> ls = null;
		String msg = null;
		try {
			BasicConfigurator.configure();
			sessionObj = CartHelper.buildSessionFactory().openSession();
			tx = sessionObj.beginTransaction();
			Query q = sessionObj.createQuery("from Cart");
			ls = q.list();
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// Close hibernate session.
			//sessionObj.close();
		}
		return ls;
	}


	public void insert() {
		// TODO Auto-generated method stub
		
	}
	}
	

