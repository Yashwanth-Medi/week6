package com.infinite.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UpdateCart {

	
}
