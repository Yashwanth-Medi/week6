package com.infinite.interfac;

import java.util.List;

import com.infinite.Pojo.Cart;

public interface ICart {

	public void insert();

	public void update();

	public void delete();

	public List<Cart> display();

}